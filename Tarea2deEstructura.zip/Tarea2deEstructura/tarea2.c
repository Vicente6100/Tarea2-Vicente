#include "tdas/extra.h"
#include "tdas/list.h"
#include "tdas/map.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
  char id[100];
  char artists[700];
  char album_name[700];
  char track_name[700] ;
  float tempo;
  char track_genre[700];
} Song;


// Menú principal
void mostrarMenuPrincipal() {
  limpiarPantalla();
  puts("========================================");
  puts("     Base de Datos de Canciones");
  puts("========================================");

  puts("1) Cargar Canciones");
  puts("2) Buscar por género");
  puts("3) Buscar por artista");
  puts("4) Buscar por Tempo");
  puts("5) Salir");
}

/**
 * Compara dos claves de tipo string para determinar si son iguales.
 * Esta función se utiliza para inicializar mapas con claves de tipo string.
 *
 * @param key1 Primer puntero a la clave string.
 * @param key2 Segundo puntero a la clave string.
 * @return Retorna 1 si las claves son iguales, 0 de lo contrario.
 */
int is_equal_str(void *key1, void *key2) {
  return strcmp((char *)key1, (char *)key2) == 0;
}

/**
 * Compara dos claves de tipo entero para determinar si son iguales.
 * Esta función se utiliza para inicializar mapas con claves de tipo entero.
 *
 * @param key1 Primer puntero a la clave entera.
 * @param key2 Segundo puntero a la clave entera.
 * @return Retorna 1 si las claves son iguales, 0 de lo contrario.
 */
int is_equal_int(void *key1, void *key2) {
  return *(int *)key1 == *(int *)key2; // Compara valores enteros directamente
}

/**
 * Carga canciones desde un archivo CSV y las almacena en un mapa.
 */
void cargar_canciones(Map *songs_bygenres, Map *songs_byartists, Map *songs_bytempo) {
  // Intenta abrir el archivo CSV que contiene datos de canciones
  getchar() ;
  char ruta[256] ; 
  
  puts("Ingrese la ruta del archivo .CSV") ;
  scanf("%255[^\n]", ruta) ; //registra la ruta del archivo
  
  FILE *archivo = fopen(ruta, "r");
  if (archivo == NULL) {
    perror(
        "Error al abrir el archivo"); // Informa si el archivo no puede abrirse
    return;
  }

  char **campos;
  // Leer y parsear una línea del archivo CSV. La función devuelve un array de
  // strings, donde cada elemento representa un campo de la línea CSV procesada.
  campos = leer_linea_csv(archivo, ','); // Lee los encabezados del CSV

  // Lee cada línea del archivo CSV hasta el final
  while ((campos = leer_linea_csv(archivo, ',')) != NULL) {
    
    
    // Crea una nueva estructura Song y almacena los datos de cada canción
    Song *cancion = (Song *)malloc(sizeof(Song));
    strcpy(cancion->id, campos[0]);        // Asigna ID
    strcpy(cancion->artists, campos[2]);     // Asigna los artistas
    strcpy(cancion->album_name, campos[3]); // Asigna el nombre del album
    strcpy(cancion->track_name, campos[4]); // Asigna el nombre de la cancion
    cancion->tempo = atof(campos[18]) ;     // Asigna el tempo de la cancion
    strcpy(cancion->track_genre, campos[20]); // Asigna el genero de la cancion


    // Busca el genero en el mapa songs_bygenres
    MapPair *genre_pair = map_search(songs_bygenres, cancion->track_genre);

    // Si el genero no existe en el mapa, crea una nueva lista y la agrega al mapa
    if (genre_pair == NULL) {
        List *nueva_lista = list_create();
        list_pushBack(nueva_lista, cancion);
        map_insert(songs_bygenres, cancion->track_genre, nueva_lista);
    } 
    else {
        // Si el genero ya existe en el mapa, se obtiene la lista y agrega la cancion
        List *genre_list = (List *) genre_pair->value;
        list_pushBack(genre_list, cancion);
    }

    
    List *lista_artista = split_string(campos[2], ";") ;  //Como los artistas estan separados por ; 
                                                          //en caso de ser mas de uno, lee hasta encontrar un ; 
                                                          //y registra el nombre en una lista, esto se repite para todos los artistas de la cancion
    char *artista = list_first(lista_artista) ;
    while (artista != NULL){ //El bucle recorre todos los artistas de la cancion

      // Busca el artista en el mapa songs_byartists
      MapPair *artists_pair = map_search(songs_byartists, artista) ;
      // Si el Artista no existe en el mapa, crea una nueva lista y la agrega al mapa
      if (artists_pair == NULL){
        List *nueva_lista = list_create() ;
        list_pushBack(nueva_lista, cancion) ;
        map_insert(songs_byartists, artista, nueva_lista) ;
      }
      else{
        // Si el artista ya existe en el mapa, se obtiene la lista y agrega la cancion
        List *canciones_artista = (List *) artists_pair->value ;
        list_pushBack(canciones_artista, cancion) ;
      }
      artista = list_next(lista_artista) ; //avanza la lista de los artistas de la cancion
    }

    // Clasifica la cancion segun su velocidad
    char *velocidad ;
    if (cancion->tempo < 80.0) velocidad = "Lentas" ;
    else if (cancion->tempo <= 120.0) velocidad = "Moderadas" ;
    else velocidad = "Rápidas" ;
    
    MapPair *tempo_pair = map_search(songs_bytempo, velocidad) ; // Busca el tempo en el mapa songs_bytempo
    if (tempo_pair == NULL){  // Si el tempo no existe en el mapa, crea una nueva lista y la agrega al mapa
      List *nueva_lista = list_create() ;
      list_pushBack(nueva_lista, cancion) ;
      map_insert(songs_bytempo, velocidad, nueva_lista) ;
    }  
    else{ // Si el tempo ya existe en el mapa, se obtiene la lista y agrega la cancion
      List *tempo_list = (List *) tempo_pair->value ;
      list_pushBack(tempo_list, cancion) ;
    }

  }
  fclose(archivo); // Cierra el archivo después de leer todas las líneas

  printf("Se cargaron todas las canciones\n");

}

/**
 * Busca y muestra la información de una cancion por su género en un mapa.
 */

void buscar_por_genero(Map *songs_bygenres) {
  char genero[50];

  // Solicita al usuario el genero de la cancion
  printf("Ingrese el género de la canción: \n");
  scanf("%s", genero); // Lee el genero del teclado

  MapPair *pair = map_search(songs_bygenres, genero); // Busca el par clave-valor en el mapa usando el género proporcionado

  if (pair != NULL) { // Si se encontró el par clave-valor, se extrae y muestra la información de la cancion
      printf("Canciones del género %s \n", genero) ;

      List* lista_canciones = pair->value;
      Song *cancion = list_first(lista_canciones); // Obtiene el puntero a la lista de canciones del género

      while (cancion != NULL) {
        printf("ID: %s || Artistas: %s || Nombre del Álbum: %s || Nombre de la Canción: %s || Tempo: %f\n", 
          cancion->id, cancion->artists, cancion->album_name, cancion->track_name, cancion->tempo);
        cancion = list_next(lista_canciones);
      }
  }
  else{ // Si el género no está en el Mapa, se informa al usuario
    puts("No se encontraron canciones del género solicitado") ;
  }
} 

void buscar_por_artista(Map *songs_byartists) {
  
  char artista[100]; // Buffer para almacenar el nombre del artista buscado
  getchar() ;
  // Solicita al usuario el nombre del artista
  printf("Ingrese el nombre del artista: \n");
  scanf("%99[^\n]", artista); // Lee el nombre buscado
  // Busca el par clave-valor en el mapa usando el nombre proporcionado

  MapPair *pair = map_search(songs_byartists, artista);

  // Si se encontró el par clave-valor, se extrae y muestra la información de la
  // cancion
  if (pair != NULL) {
    printf("Canciones de %s\n", artista ) ;
    List *lista_de_canciones = pair->value ;
    Song *cancion = list_first(lista_de_canciones) ;// Obtiene el puntero a la lista de canciones del artista
    // Muestra los datos de cada cancion del artista 
    while(cancion != NULL){

      printf("ID: %s, Artistas: %s, Nombre del Álbum: %s, Nombre de la Canción: %s, Tempo: %f, Género: %s\n", 
          cancion->id, cancion->artists, cancion->album_name, cancion->track_name, cancion->tempo, cancion->track_genre);
      cancion = list_next(lista_de_canciones) ;
    }

  } 
  else {
    // Si no se encuentra al artista se informa al usuario
    printf("El/la artista < %s > no está en el registro\n", artista);
  }
}

void buscar_por_tempo(Map *songs_bytempo){
  
  char opcion ;
  getchar() ; 
  //Solicita al usuario la velocidad que desea buscar
  puts("Seleccione una categoría :") ;
  puts("1) Lentas (menos de 80 BPM");
  puts("2) Moderadas (entre 80 y 120 BMP)");
  puts("3) Rápidas (más de 120 BPM");
  
  scanf("%c", &opcion) ;

  char *velocidad ;
  switch (opcion) {
    case '1':
      velocidad = "Lentas" ;
      break;
    case '2':
      velocidad = "Moderadas" ;
      break;
    case '3':
      velocidad = "Rápidas" ;
      break;
    default :
      puts("Opcion inválida") ;
      return ;
  }

  MapPair *pair = map_search(songs_bytempo, velocidad) ; // Busca el par clave-valor en el mapa usando el nombre proporcionado

  if (pair != NULL){ // Si se encontró el par clave-valor, se extrae y muestra la información de la cancion
    printf("Canciones %s\n", velocidad) ;
    List *lista_de_canciones = pair->value ;
    Song *cancion = list_first(lista_de_canciones) ;
    while(cancion != NULL){ // Muestra los datos de cada cancion del artista
      printf("ID: %s, Artistas: %s, Nombre del Álbum: %s, Nombre de la Canción: %s, Tempo: %f\n", 
        cancion->id, cancion->artists, cancion->album_name, cancion->track_name, cancion->tempo);
      cancion = list_next(lista_de_canciones);

    }
  }
    // Si no se encuentra la velocidad se informa al usuario
  else{
    printf("No se encontraron canciones de velocidad %s\n",velocidad) ;
  }

}


int main() {
  char opcion; // Variable para almacenar una opción ingresada por el usuario
               // (sin uso en este fragmento)

  // Crea un mapa para almacenar canciones, utilizando una función de
  // comparación que trabaja con claves de tipo string.
  Map *songs_bygenres = map_create(is_equal_str);
  Map *songs_byartists = map_create(is_equal_str);
  Map *songs_bytempo =  map_create(is_equal_str);

  // Recuerda usar un mapa por criterio de búsqueda

  do {
    mostrarMenuPrincipal();
    printf("Ingrese su opción: \n");
    scanf(" %c", &opcion);
    switch (opcion) {
    case '1':
      cargar_canciones(songs_bygenres, songs_byartists, songs_bytempo);
      break;
    case '2':
      buscar_por_genero(songs_bygenres);   
      break;
    case '3':
      buscar_por_artista(songs_byartists);
      break;
    case '4':
      buscar_por_tempo(songs_bytempo);
      break;
    case '5' :
      break ;  
    default :
      puts("Opcion inválida") ;
      break ;
    }
    presioneTeclaParaContinuar();

  } while (opcion != '5');

  return 0;
}

